
#include <errno.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

#include "hdf5c.h"
#include "hdf5.h"
#include "H5public.h"
#include "H5LTpublic.h"

// #define MAX_CONCURRENT_DATASETS 20

typedef enum _OpenType {
  Read_OT,
  Write_OT,
  Create_OT
} OpenType;

struct hdf5c_buffer {
  int used;
  hid_t file_id;
  char datasetname[ 1024 ];
  int memsize, size, num_int, num_real;
  int *intarray[ 20 ];
  double *doublearray[ 20 ];
};

typedef struct _CPostHdf5File {
   hid_t file_id;
   hid_t group_id;
   char group_path[ 1024 ];
   struct hdf5c_buffer file_buffer[ MAX_CONCURRENT_DATASETS ];
   char error_buffer[ 8192 ];
} CPostHdf5File;


const char *hdf5c_f_get_version() {
  static char *version_str = NULL;

  if ( !version_str ) {
    char buf[ 1024 ];
    unsigned major_number, minor_number, patch_number;
    hbool_t is_thread_safe = 0;

    // retrieve the library version
    herr_t h5_error = H5get_libversion( &major_number, &minor_number, &patch_number );
    if ( h5_error >= 0 ) {
      // is this a thread-safe library build?
      h5_error = H5is_library_threadsafe( &is_thread_safe );
    }
    if ( h5_error >= 0 ) {
      snprintf( buf, 1024, "HDF5 %d.%d.%d  ( Thread-safety %s )", major_number, minor_number, patch_number, ( is_thread_safe > 0 ) ? "enabled" : "disabled" );
      version_str = strdup( buf );
    }
  }
  return version_str;
}

// -1 on error
int hdf5c_f_is_thread_safe( void ) {
  int ret_value = -1;
  hbool_t is_thread_safe = 0;
  // is this a thread-safe library build?
  herr_t h5_error = H5is_library_threadsafe( &is_thread_safe );
  if ( h5_error >= 0 ) { // ok
    ret_value = is_thread_safe ? 1 : 0;
  } else {
    ret_value = -1;
  }
  return ret_value;
}

// returns -1 if error
int checkHDF5threadSafe( void ) {
    unsigned major_number, minor_number, patch_number;
    static hbool_t is_thread_safe = 0;
    static int checked = 0;

    if ( !checked ) {
      // retrieve the library version
      herr_t h5_error = H5get_libversion( &major_number, &minor_number, &patch_number );
      if ( h5_error < 0 ) {
	    return -1;
      }
      // is this a thread-safe library build?
      h5_error = H5is_library_threadsafe( &is_thread_safe );
      if ( h5_error < 0 ) {
	    return -1;
      }

      printf( "Welcome to HDF5 %d.%d.%d  ( Thread-safety %s )\n", major_number, minor_number, patch_number, ( is_thread_safe > 0 ) ? "enabled" : "disabled" );
      checked = 1;
    }
    return ( is_thread_safe > 0 ) ? 0 : -1;
}

CPostHdf5File *new_CPostHdf5File( void ) {
  // thrread safety checking is done when opening second hdf5 file in gidpostHDF5.c new_CurrentHdf5WriteData()
  // int fail = checkHDF5threadSafe();
  // if ( fail ) {
  //   return NULL;
  // }
   CPostHdf5File *obj = ( CPostHdf5File * )malloc( sizeof( CPostHdf5File ));
   if ( obj ) {
     memset( obj, 0, sizeof( CPostHdf5File ) );
   }
   // obj->file_id = 0;
   // obj->file_id = 0;
   // obj->group_path[ 0] = '\0';
   // for ( int i = 0; i < MAX_CONCURRENT_DATASETS; i++ ) {
   //   memset( &( obj->file_buffer[ i ] ), 0, sizeof( struct hdf5c_buffer ) );
   // }
   // obj->error_buffer[ 0] = '\0';
   return obj;
}


void delete_CPostHdf5File( CPostHdf5File *obj ) {
  free( obj );
}

#define H5_GID_COMPRESSION_LEVEL   1
/*
  // with the H5Cpp interface:
  // Using level 1 because:
  // level 6 too costly, is 4 times slower than level 1 and only gets 6,6 % reduction
  // level 2 is 12 % slower and only 1,9 % size reduction
  #define H5_GID_COMPRESSION_LEVEL   6
*/

int hdf5c_f_open( CPostHdf5File *obj, const char *zFile, OpenType otype ) {
  if ( obj == NULL ) {
    return -1;
  }

  int i,is_hdf5;
  hid_t file_id;
  unsigned int flags=H5F_ACC_RDWR;
  
  H5Eset_auto(H5E_DEFAULT,NULL,NULL);

  is_hdf5=H5Fis_hdf5(zFile);
  if(is_hdf5<=0 && otype==Read_OT){
    sprintf(obj->error_buffer,"File '%s' does not exists or is not in hdf5 format",zFile);
    return -1;
  }
  if(is_hdf5 && otype!=Create_OT){
    if(otype==Read_OT) flags=H5F_ACC_RDONLY;
    file_id=H5Fopen(zFile,flags,H5P_DEFAULT);
    if(file_id<0){
      sprintf(obj->error_buffer,"Could not open file '%s'",zFile);
      return -1;
    }
  } else {
    file_id=H5Fcreate(zFile, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);
    if(file_id<0){
      sprintf(obj->error_buffer,"could not create file '%s'",zFile);
      return -1;
    }
  }
  obj->file_id=file_id;
  for(i=0;i<MAX_CONCURRENT_DATASETS;i++){
    obj->file_buffer[i].used=0;
    obj->file_buffer[i].file_id=file_id;
    memset(obj->file_buffer[i].intarray,0,20*sizeof(int*));
    memset(obj->file_buffer[i].doublearray,0,20*sizeof(double*));
  }
  strcpy(obj->error_buffer,"");
  return 0;
}

int hdf5c_f_init( CPostHdf5File *obj, const char *zFile ) {
  /* this is equal to hdf5c_open(zFile,Create_OT) for compatibility */
  return hdf5c_f_open( obj, zFile, Create_OT);
}

int hdf5c_f_end( CPostHdf5File *obj ) {
  if ( obj == NULL ) {
    return -1;
  }

  int i, j;
  herr_t ht_ret = 0;
  if ( obj->group_id >= 0 ) {
    H5Gclose( obj->group_id );
    obj->group_id = 0;
  }
  if ( obj->file_buffer[ 0 ].file_id > 0 ) {
    ht_ret = H5Fclose( obj->file_buffer[ 0 ].file_id );
  }
  for ( i = 0; i < MAX_CONCURRENT_DATASETS; i++ ) {
    for ( j = 0; j < 20; j++ ) {
      if ( obj->file_buffer[ i ].intarray[ j ] ) free( obj->file_buffer[ i ].intarray[ j ] );
      if ( obj->file_buffer[ i ].doublearray[ j ] ) free( obj->file_buffer[ i ].doublearray[ j ] );
    }
  }

  return ht_ret;
}

int hdf5c_f_flush( CPostHdf5File *obj ) {
  if ( obj == NULL ) {
    return -1;
  }

  return H5Fflush( obj->file_id, H5F_SCOPE_GLOBAL );
}

char *hdf5c_f_last_error( CPostHdf5File *obj ) {
  return obj ? obj->error_buffer : NULL;
}

/*################################################################################
 *    write functions
 *################################################################################*/

int hdf5c_f_create_group( CPostHdf5File *obj, const char *name ) {
  if ( obj == NULL ) {
    return -1;
  }

  hid_t ht_group;

  ht_group=H5Gopen(obj->file_id,name,H5P_DEFAULT);
  if(ht_group>=0){
    H5Gclose(ht_group);
    return 0;
  }
  ht_group=H5Gcreate(obj->file_id,name,0,H5P_DEFAULT,H5P_DEFAULT);
  if(ht_group<0){
    sprintf(obj->error_buffer,"name '%s'. error creating group",name);
    return -1;
  }
  H5Gclose (ht_group);
  return 1;
}

int hdf5c_f_set_attribute( CPostHdf5File *obj, const char *name, const char *attname, const char *value ) {
  if ( obj == NULL ) {
    return -1;
  }

  hid_t ht_err;

  /*
    ht_err=H5LTset_attribute_char(obj->file_buffer.file_id,name,attname,value,strlen(value));
  */
  ht_err = H5LTset_attribute_string( obj->file_id, name, attname, value );
  if ( ht_err < 0 ) {
    sprintf( obj->error_buffer, "cannot set attribute to '%s'", name );
    return -1;
  }
  return 0;
}

int hdf5c_f_start_dataset( CPostHdf5File *obj, const char *name, int num_int, int num_real ) {
  if ( obj == NULL ) {
    return -1;
  }

  int i,dataset_id;
  hid_t ht_group;
  
  for(dataset_id=0;dataset_id<MAX_CONCURRENT_DATASETS;dataset_id++)
    if(!obj->file_buffer[dataset_id].used) break;
  if(dataset_id==MAX_CONCURRENT_DATASETS){
    sprintf(obj->error_buffer,"Too many concurrent datasets n=%d",MAX_CONCURRENT_DATASETS);
    return -1;
  }
  
  if(strlen(name)>1023){
    sprintf(obj->error_buffer,"name '%s'. too long",name);
    return -1;
  }
  strcpy(obj->file_buffer[dataset_id].datasetname,name);
  ht_group=H5Gopen(obj->file_buffer[dataset_id].file_id,name,H5P_DEFAULT);
  if(ht_group<0){
    ht_group=H5Gcreate(obj->file_buffer[dataset_id].file_id,name,0,H5P_DEFAULT,H5P_DEFAULT);
    if(ht_group<0){
      sprintf(obj->error_buffer,"name '%s'. error creating group",name);
      return -1;
    }
  }
  H5Fclose (ht_group);
  
  obj->file_buffer[dataset_id].used=1;
  if(obj->file_buffer[dataset_id].memsize==0){
    obj->file_buffer[dataset_id].memsize=10000;
  }
  for(i=obj->file_buffer[dataset_id].num_int;i<num_int;i++){
    if(!obj->file_buffer[dataset_id].intarray[i])
      obj->file_buffer[dataset_id].intarray[i]=(int*) malloc(( size_t)obj->file_buffer[dataset_id].memsize*sizeof(int));
  }
  obj->file_buffer[dataset_id].num_int=num_int;
  for(i=obj->file_buffer[dataset_id].num_real;i<num_real;i++){
    if(!obj->file_buffer[dataset_id].doublearray[i])
      obj->file_buffer[dataset_id].doublearray[i]=(double*) malloc(( size_t)obj->file_buffer[dataset_id].memsize*sizeof(double));
  }
  obj->file_buffer[dataset_id].num_real=num_real;
  obj->file_buffer[dataset_id].size=0;
  return dataset_id;
}

int hdf5c_f_add_to_dataset( CPostHdf5File *obj, int dataset_id, const int intvalues[], const double doublevalues[] ) {
  if ( obj == NULL ) {
    return -1;
  }

  int i;
  if(obj->file_buffer[dataset_id].size==obj->file_buffer[dataset_id].memsize){
    obj->file_buffer[dataset_id].memsize*=2;
    for(i=0;i<20;i++){
      if(obj->file_buffer[dataset_id].intarray[i])
	obj->file_buffer[dataset_id].intarray[i]=realloc(obj->file_buffer[dataset_id].intarray[i],
							    ( size_t)obj->file_buffer[dataset_id].memsize*sizeof(int));
      if(obj->file_buffer[dataset_id].doublearray[i])
	obj->file_buffer[dataset_id].doublearray[i]=realloc(obj->file_buffer[dataset_id].doublearray[i],
							       ( size_t)obj->file_buffer[dataset_id].memsize*sizeof(double));
    }
  }
  for(i=0;i<obj->file_buffer[dataset_id].num_int;i++)
    obj->file_buffer[dataset_id].intarray[i][obj->file_buffer[dataset_id].size]=intvalues[i];
  for(i=0;i<obj->file_buffer[dataset_id].num_real;i++)
    obj->file_buffer[dataset_id].doublearray[i][obj->file_buffer[dataset_id].size]=doublevalues[i];
  obj->file_buffer[dataset_id].size++;
  return 0;
}

static int hdf5c_f_create_int_dataset_from_buffer( CPostHdf5File *obj, int dataset_id,char* name,int compress,int length,int* intarray) {
  if ( obj == NULL ) {
    return -1;
  }

  hsize_t dims[1],chunk_size[1] ;
  hid_t ht_err,plist,sid,dataset;

  dims[0]= ( hsize_t)length;
  if(compress>0){
    chunk_size[0]= ( hsize_t)length;
    plist=H5Pcreate(H5P_DATASET_CREATE);
    H5Pset_chunk(plist, 1, chunk_size);
    H5Pset_deflate(plist, ( unsigned int)compress);
    sid = H5Screate_simple(1, dims, NULL);
    dataset = H5Dcreate(obj->file_buffer[dataset_id].file_id,name,H5T_NATIVE_INT,sid,
		        H5P_DEFAULT,plist,H5P_DEFAULT);
    ht_err=H5Dwrite(dataset,H5T_NATIVE_INT, H5S_ALL, H5S_ALL, H5P_DEFAULT,intarray);
    H5Dclose(dataset);
    H5Sclose(sid);
    H5Pclose(plist);
  } else {
    ht_err=H5LTmake_dataset_int(obj->file_buffer[dataset_id].file_id,name,1,dims,intarray);
  }
  if(ht_err<0){
    sprintf(obj->error_buffer,"cannot set array name '%s'",name);
    return -1;
  }
  return 0;
}

static int hdf5c_f_create_double_dataset_from_buffer( CPostHdf5File *obj, int dataset_id,char* name,int compress,int length,double* doublearray) {
  if ( obj == NULL ) {
    return -1;
  }

  hsize_t dims[1],chunk_size[1] ;
  hid_t ht_err,plist,sid,dataset;

  dims[0]=( hsize_t)length;
  if(compress>0){
    chunk_size[0]=( hsize_t)length;
    plist=H5Pcreate(H5P_DATASET_CREATE);
    H5Pset_chunk(plist, 1, chunk_size);
    H5Pset_deflate(plist, ( unsigned int)compress);
    sid = H5Screate_simple(1, dims, NULL);
    dataset = H5Dcreate(obj->file_buffer[dataset_id].file_id,name,H5T_NATIVE_DOUBLE,sid,
		        H5P_DEFAULT,plist,H5P_DEFAULT);
    ht_err=H5Dwrite(dataset,H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT,doublearray);
    H5Dclose(dataset);
    H5Sclose(sid);
    H5Pclose(plist);
  } else {
    ht_err=H5LTmake_dataset_double(obj->file_buffer[dataset_id].file_id,name,1,dims,doublearray);
  }
  if(ht_err<0){
    sprintf(obj->error_buffer,"cannot set array name '%s'",name);
    return -1;
  }
  return 0;
}

int hdf5c_f_end_dataset( CPostHdf5File *obj, int dataset_id ) {
  if ( obj == NULL ) {
    return -1;
  }

  int i,fail,inum=1;
  int compress=H5_GID_COMPRESSION_LEVEL;
  char buf[2048];
  for(i=0;i<obj->file_buffer[dataset_id].num_int;i++){
    sprintf(buf,"%s/%d",obj->file_buffer[dataset_id].datasetname,inum);
    fail=hdf5c_f_create_int_dataset_from_buffer( obj, dataset_id,buf,compress,obj->file_buffer[dataset_id].size,
      obj->file_buffer[dataset_id].intarray[i]);
    if(fail<0) return fail;
    inum++;
  }
  for(i=0;i<obj->file_buffer[dataset_id].num_real;i++){
    sprintf(buf,"%s/%d",obj->file_buffer[dataset_id].datasetname,inum);
    fail=hdf5c_f_create_double_dataset_from_buffer( obj, dataset_id,buf,compress,obj->file_buffer[dataset_id].size,
      obj->file_buffer[dataset_id].doublearray[i]);
    if(fail<0) return fail;
    inum++;
  }
  obj->file_buffer[dataset_id].used=0;
  return 0;
}

static int _hdf5c_f_create_dataset( CPostHdf5File *obj, const char *dataset_name, int dataset_subindex, 
				   int compress, int length, t_hdf5c_dataset_type ds_type, const void *data_array ) {
  if ( obj == NULL ) {
    return -1;
  }

  char name_dataset_subtable[ 2048 ];
  snprintf( name_dataset_subtable, 2048, "%s/%d", dataset_name, dataset_subindex );

  hsize_t dims[ 1 ];
  hid_t ht_err = 0;

  int fail = 0;
  dims[ 0 ] = ( hsize_t )length;
  if ( compress > 0 ) {
    hid_t dataset_id = 0;
    hid_t type_id = H5T_NATIVE_INT;
    switch ( ds_type ) {
      case HDF5C_DATASET_INTEGER:   type_id = H5T_NATIVE_INT;    break;
      case HDF5C_DATASET_DOUBLE:    type_id = H5T_NATIVE_DOUBLE; break;
      case HDF5C_DATASET_NONE:      fail = -1; break;
    }
    if ( !fail ) {
      hsize_t chunk_size[ 1 ];
      chunk_size[ 0 ] = ( hsize_t )length;
      hid_t plist = H5Pcreate( H5P_DATASET_CREATE );
      H5Pset_chunk( plist, 1, chunk_size );
      H5Pset_deflate( plist, ( unsigned int )compress );
      hid_t sid = H5Screate_simple( 1, dims, NULL );
      dataset_id = H5Dcreate( obj->file_id, name_dataset_subtable, type_id, sid, H5P_DEFAULT, plist, H5P_DEFAULT );
      ht_err = H5Dwrite( dataset_id, type_id, H5S_ALL, H5S_ALL, H5P_DEFAULT, data_array );
      H5Dclose( dataset_id );
      H5Sclose( sid );
      H5Pclose( plist );
    }
  } else {
    switch ( ds_type ) {
      case HDF5C_DATASET_INTEGER:
	ht_err = H5LTmake_dataset_int( obj->file_id, name_dataset_subtable, 1, dims, ( const int *)data_array );
	break;
      case HDF5C_DATASET_DOUBLE:
	ht_err = H5LTmake_dataset_double( obj->file_id, name_dataset_subtable, 1, dims, ( const double *)data_array );
	break;
      case HDF5C_DATASET_NONE:
	fail = -1;
	ht_err = -1;
	break;
    }
  }
  if ( ht_err < 0 ) {
    sprintf( obj->error_buffer, "cannot set array name '%s'", name_dataset_subtable );
    fail = -1;
  } else {
    fail = 0;
  }
  return fail;
}

// hdf5c_write_dataset_list = hdf5c_f_start_dataset() + hdf5c_f_add_to_dataset() + hdf5c_f_end_dataset()
int hdf5c_write_dataset_list( CPostHdf5File *obj, const char *name, int num_datasets, int num_values, 
			      t_hdf5c_dataset_type *data_types, const void **data_values ) {
  if ( obj == NULL ) {
    return -1;
  }

  if ( strlen( name ) > 1023 ) {
    sprintf( obj->error_buffer, "name '%s'. too long", name );
    return -1;
  }

  // check if name exists, if not, create it.
  hid_t ht_group = 0;
  ht_group = H5Gopen( obj->file_id, name, H5P_DEFAULT );
  if ( ht_group < 0 ) {
    ht_group = H5Gcreate( obj->file_id, name, 0, H5P_DEFAULT, H5P_DEFAULT );
    if ( ht_group < 0 ) {
      sprintf( obj->error_buffer, "name '%s'. error creating group", name );
      return -1;
    }
  }
  H5Fclose( ht_group );

  // write datasets: ids, x, y, z
  int compress = H5_GID_COMPRESSION_LEVEL;
  int dataset_subindex = 1; 
  int fail = 0;
  for ( int idx_data = 0; ( idx_data < num_datasets) && ( data_types[ idx_data] != HDF5C_DATASET_NONE) && data_values[ idx_data]; idx_data++ ) {
    t_hdf5c_dataset_type current_type = data_types[ idx_data ];
    const void *current_data = data_values[ idx_data ];
    fail = _hdf5c_f_create_dataset( obj, name, dataset_subindex, compress, num_values, current_type, current_data );
    if ( fail ) {
      break;
    }
    dataset_subindex++;
  }

  return fail;
}

/*################################################################################
 *    Read functions
 *################################################################################*/

int hdf5c_f_num_children( CPostHdf5File *obj, const char *group_path ) {
  if ( obj == NULL ) {
    return -1;
  }

  hid_t ht_err;
  hsize_t num_obj;

  if(obj->group_id>=0) H5Gclose(obj->group_id);
  obj->group_id=H5Gopen(obj->file_id,group_path,H5P_DEFAULT);
  if(obj->group_id<0){
    sprintf(obj->error_buffer,"Could not find group '%s'",group_path);
    return -1;
  }
  strcpy(obj->group_path,group_path);
  
  ht_err=H5Gget_num_objs(obj->group_id,&num_obj);

  if(ht_err<0){
    sprintf(obj->error_buffer,"group '%s' is not a correct group",group_path);
    return -1;
  }
  return (int)num_obj;
}

int hdf5c_f_get_children_name( CPostHdf5File *obj, const char *group_path, int index, char *name, int max_len ) {
  if ( obj == NULL ) {
    return -1;
  }

  ssize_t len,len0;
  if(obj->group_id<=0 || strcmp(group_path,obj->group_path)!=0){
    if(obj->group_id>=0) H5Gclose(obj->group_id);
    obj->group_id=H5Gopen(obj->file_id,group_path,H5P_DEFAULT);
    if(obj->group_id<0){
      sprintf(obj->error_buffer,"Could not find group '%s'",group_path);
      return -1;
    }
    strcpy(obj->group_path,group_path);
  }
  if((int)strlen(group_path)>=max_len-10) return -1;
  strcpy(name,group_path);
  if(name[strlen(name)-1]!='/'){
    strcat(name,"/");
  }
  len0= ( ssize_t)strlen(name);
  len=H5Gget_objname_by_idx(obj->group_id, ( hsize_t)index,&name[len0],( size_t)max_len-( size_t)len0);
  return ( int)( len+len0);
}

int hdf5c_f_get_attribute( CPostHdf5File *obj, const char *obj_name, char *att_name, char *value, int max_len ) {
  if ( obj == NULL ) {
    return -1;
  }

  int rank;
  hid_t ht_err;
  hsize_t dims[10];
  size_t  type_size;
  H5T_class_t class_id;
  
  ht_err=H5LTget_attribute_info(obj->file_id,obj_name,att_name, dims,&class_id,&type_size);
  if(ht_err<0){
    sprintf(obj->error_buffer,"name '%s'. Attribute cannot be retrieved '%s'",obj_name,att_name);
    return -1;
  }  
  if(class_id==H5T_INTEGER) {
    if(type_size!=1){
      sprintf(obj->error_buffer,"name '%s' cannot be retrieved. Bad type %d. Has to be one array of char",
	obj_name,class_id);
      return -1;
    }
    ht_err=H5LTget_attribute_ndims(obj->file_id,obj_name,att_name,&rank);
    /*
      rank is 1 for H5T_INTEGER
    */
    if(ht_err<0 || rank!=1){
      sprintf(obj->error_buffer,"name '%s'. Attribute cannot be retrieved '%s'",obj_name,att_name);
      return -1;
    }
    if(dims[0]>= ( hsize_t)max_len) return -1;
    ht_err=H5LTget_attribute_char(obj->file_id,obj_name,att_name,value);
  } else if (class_id==H5T_STRING){
    if(type_size<1){
      sprintf(obj->error_buffer,"name '%s' cannot be retrieved. Bad type %d. Has to be one array of char",
	obj_name,class_id);
      return -1;
    }
    ht_err=H5LTget_attribute_ndims(obj->file_id,obj_name,att_name,&rank);
    /*
      rank is 0 for H5T_STRING
    */
    if(ht_err<0 || rank!=0){
      sprintf(obj->error_buffer,"name '%s'. Attribute cannot be retrieved '%s'",obj_name,att_name);
      return -1;
    }
    if((int)type_size>=max_len) return -1;
    ht_err=H5LTget_attribute_string(obj->file_id,obj_name,att_name,value);
  } else {
    sprintf(obj->error_buffer,"name '%s' cannot be retrieved. Bad type %d Has to be one array of char or a string",
      obj_name,class_id);
    return -1;
  }
  return 0;
}

int hdf5c_f_open_dataset_list( CPostHdf5File *obj, const char *obj_name, int *num_int, int *num_real ) {
  if ( obj == NULL ) {
    return -1;
  }

  int i,rank,idx;
  hsize_t num;
  char name[1024];
  
  hid_t ht_err,ht_dataset,ht_type;
  hsize_t dims[1];
  H5T_class_t class_id;
  size_t type_size;

  num=( hsize_t)hdf5c_f_num_children( obj, obj_name);
  if(num<=0) return -1;
  
  obj->file_buffer[0].num_int=obj->file_buffer[0].num_real=0;
  
  for(i=0;i< ( int)num;i++){
    hdf5c_f_get_children_name( obj, obj_name,i,name,1024);
    ht_err=H5LTget_dataset_ndims(obj->file_id,name,&rank);
    if(ht_err<0 || rank!=1){
      sprintf(obj->error_buffer,"dataset name '%s' cannot be retrieved",name);
      return -1;
    }
    ht_err=H5LTget_dataset_info (obj->file_id,name,dims,&class_id,NULL);
    if(ht_err<0){
      sprintf(obj->error_buffer,"dataset name '%s' cannot be retrieved",name);
      return -1;
    }
    ht_dataset=H5Dopen(obj->file_id,name,H5P_DEFAULT);
    ht_type=H5Dget_type(ht_dataset);
    type_size=H5Tget_size(ht_type);
    H5Dclose(ht_dataset);
    H5Tclose(ht_type);
    
    if(class_id==H5T_INTEGER){
      idx=obj->file_buffer[0].num_int;
      obj->file_buffer[0].intarray[idx]=malloc(((size_t)dims[0])*sizeof(int));
      ht_err=H5LTread_dataset_int (obj->file_id,name,obj->file_buffer[0].intarray[idx]);
      if(ht_err<0){
	sprintf(obj->error_buffer,"array name '%s' cannot be retrieved",name);
	return -1;
      }
      obj->file_buffer[0].num_int++;
    }
    else if(class_id==H5T_FLOAT && type_size==4){
      sprintf(obj->error_buffer,"4 byte floats not supported");
      return -1;
    }
    else if(class_id==H5T_FLOAT && type_size==8){
      idx=obj->file_buffer[0].num_real;
      obj->file_buffer[0].doublearray[idx]=malloc(((size_t)dims[0])*sizeof(double));
      ht_err=H5LTread_dataset_double(obj->file_id,name,obj->file_buffer[0].doublearray[idx]);
      if(ht_err<0){
	sprintf(obj->error_buffer,"array name '%s' cannot be retrieved",name);
	return -1;
      }
      obj->file_buffer[0].num_real++;
    }
    else {
      sprintf(obj->error_buffer,"array name '%s' cannot be retrieved. unknown type=%d,%llu",
	      name,class_id,( long long unsigned int)type_size);
      return -1;
    }
    obj->file_buffer[0].size=(int)dims[0];
  }
  obj->file_buffer[0].used=1;
  *num_int=obj->file_buffer[0].num_int;
  *num_real=obj->file_buffer[0].num_real;
  return obj->file_buffer[0].size;
}

int hdf5c_f_give_dataset_list_values( CPostHdf5File *obj, int index, int int_values[], double double_values[] ) {
  if ( obj == NULL ) {
    return -1;
  }

  int i;
  if(index<0 || index>=obj->file_buffer[0].size){
    return -1;
  }
  for(i=0;i<obj->file_buffer[0].num_int;i++){
    int_values[i]=obj->file_buffer[0].intarray[i][index];
  }
  for(i=0;i<obj->file_buffer[0].num_real;i++){
    double_values[i]=obj->file_buffer[0].doublearray[i][index];
  }
  return 0;
}

int hdf5c_f_close_dataset_list( CPostHdf5File *obj ) {
  if ( obj == NULL ) {
    return -1;
  }

  int i;
  for(i=0;i<obj->file_buffer[0].num_int;i++){
    free(obj->file_buffer[0].intarray[i]);
    obj->file_buffer[0].intarray[i]=NULL;
  }
  for(i=0;i<obj->file_buffer[0].num_real;i++){
    free(obj->file_buffer[0].doublearray[i]);
    obj->file_buffer[0].doublearray[i]=NULL;
  }
  obj->file_buffer[0].num_int=obj->file_buffer[0].num_real=0;
  obj->file_buffer[0].used=0;
  return 0;
}
